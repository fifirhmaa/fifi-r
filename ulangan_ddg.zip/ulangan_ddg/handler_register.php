<?php
$id = $_POST['id'];
$nama = $_POST['nama'];
$email = $_POST['email'];
$password = $_POST['password'];

$koneksi = new mysqli('localhost', 'root', '', 'register');
if ($koneksi) {
    echo "koneksi berhasil";
}else { 
    echo $koneksi->error;
}

$insert = $koneksi->query("INSERT INTO register 
(id, nama, email, password)
values
($id, '$nama', '$email', '$password')
");

if ($insert) {
    echo "Insert Data Berhasil";
}else {
    echo"Gagal Insert Data";
}


?>